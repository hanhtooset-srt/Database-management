
DROP TABLE IF EXISTS Transaction cascade;
DROP TABLE IF EXISTS Reservation cascade;
DROP TABLE IF EXISTS Member cascade;
DROP TABLE IF EXISTS Staff cascade;
DROP TABLE IF EXISTS Book cascade;

DROP TYPE IF EXISTS book_category_type;
DROP TYPE IF EXISTS address_type;

DROP FUNCTION IF EXISTS get_transaction_details;
DROP PROCEDURE IF EXISTS find_transaction_details(VARCHAR);
DROP VIEW IF EXISTS CombinedMemberStaff;


CREATE TYPE book_category_type AS ENUM (
    'Art','Biography','Business',
    'Chick-lit','Children''s','Christian',
	'Classics','Comics','Contemporary',
    'Cookbooks','Crime','Fantasy',
    'Fiction','Historical fiction','Horror',
    'Humour and satire','Non-Fiction','Science',
    'History','Technology'
);


CREATE TYPE address_type AS (
    street VARCHAR(100),
    city VARCHAR(60),
    postal_code VARCHAR(15)
);


CREATE TABLE Member (
    MemberID Int PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Address address_type,
    PhoneNumber VARCHAR(15) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    StartDate Timestamp
);


CREATE TABLE Staff (
    StaffID Int PRIMARY KEY,
    SName VARCHAR(100) NOT NULL,
    position VARCHAR(50) NOT NULL 
);


CREATE TABLE Book (
    BookID Int PRIMARY KEY,
    Title VARCHAR(200) NOT NULL,
    Author VARCHAR(100) NOT NULL,
    PublishedYear INT NOT NULL,
    Category book_category_type,
    AvailableCopies INT NOT NULL
);


CREATE TABLE Transaction (
    TransactionID Int PRIMARY KEY,
    MemberID INT REFERENCES Member(MemberID) ON DELETE CASCADE,
    BookID INT REFERENCES Book(BookID) ON DELETE CASCADE,
    DateIssued Timestamp NOT NULL,
    DueDate Timestamp NOT NULL,
    ReturnDate Timestamp,
    Status VARCHAR(20),
	constraint check_Status check (Status in ('Issued', 'Returned'))
);


CREATE TABLE Reservation (
    ReservationID int PRIMARY KEY,
    MemberID int REFERENCES Member(MemberID) ON DELETE CASCADE,
    BookID int REFERENCES Book(BookID) ON DELETE CASCADE,
	StaffID int REFERENCES Staff(StaffID),
    ReservationDate Timestamp,
    ExpiryDate Timestamp,
    Status varchar(20), 
	constraint check_Status check (Status IN ('Active', 'Cancelled', 'Expired'))
);







select * from Staff;
select * from Book;
select * from Transaction;
select * from Member;
select * from Reservation;


----------
Insert into Member (MemberID, Name, Address, PhoneNumber, Email, StartDate) values
(1, 'Jane Doe', ('123 Elm St', 'Springfield', '62704'), '555-1234', 'janedoe32@email.com', to_timestamp('2023-01-15', 'YYYY-MM-DD')),
(2, 'Smithy', ('456 Oak Ave', 'Metropolis', '20001'), '555-5678', 'smith678@email.com', to_timestamp('2023-03-22', 'YYYY-MM-DD')),
(3, 'Elis Davis', ('789 Pine Rd', 'Gotham',  '07030'), '555-8765', 'elisdavis795@email.com', to_timestamp('2023-05-10', 'YYYY-MM-DD')),
(4,'Walter White',('308 Negra Arroyo','New Mexico','09070'),'545-9674','waltwhite357@gmail.com',to_timestamp('2023-04-01', 'YYYY-MM-DD')),
(5,'Muhammad Matthew',('214 Daniela Plaza','New Mexico','09056'),'545-7439','Matthew37@gmail.com',to_timestamp('2023-04-28', 'YYYY-MM-DD'))
;


Insert into Staff (StaffID, SName, position) values
(1,'Johnathan','Receptionist'),
(2,'Eimi','Receptionist'),
(3,'Anna','Receptionist')
;


Insert into Book (BookID, Title, Author, PublishedYear, Category, AvailableCopies) values
(1, 'The Art of War', 'Sun Tzu', 2005, 'History', 5),
(2, 'Steve Jobs', 'Walter Isaacson', 2011, 'Biography', 3),
(3, 'Business Adventures', 'John Brooks', 1969, 'Business', 4),
(4, 'The Hunger Games', 'Suzanne Collins', 2008, 'Fiction', 6),
(5, 'The Hobbit', 'J.R.R. Tolkien', 1937, 'Fantasy', 7),
(6, 'Cooking Basics', 'Julia Child', 1961, 'Cookbooks', 2),
(7, 'The Complete Sherlock Holmes', 'Arthur Conan Doyle', 1927, 'Classics', 8),
(8, 'A Brief History of Time', 'Stephen Hawking', 1988, 'Science', 5),
(9, 'Clean Code', 'Robert C. Martin', 2008, 'Technology', 10),
(10, 'The Girl with the Dragon Tattoo', 'Stieg Larsson', 2005, 'Crime', 4)
; 

Insert into Transaction (TransactionID, MemberID, BookID, DateIssued, DueDate, ReturnDate, Status) values
(1, 2, 1, to_timestamp('2025-05-01', 'YYYY-MM-DD'), to_timestamp('2025-05-15', 'YYYY-MM-DD'), NULL, 'Issued'),
(2, 5, 3, to_timestamp('2025-04-20', 'YYYY-MM-DD'), to_timestamp('2025-05-04', 'YYYY-MM-DD'), to_timestamp('2025-05-03', 'YYYY-MM-DD'), 'Returned'),
(3, 4, 5, to_timestamp('2025-05-05', 'YYYY-MM-DD'), to_timestamp('2025-05-19', 'YYYY-MM-DD'), NULL, 'Issued'),
(4, 1, 2, to_timestamp('2025-03-15', 'YYYY-MM-DD'), to_timestamp('2025-03-29', 'YYYY-MM-DD'), to_timestamp('2025-03-28', 'YYYY-MM-DD'), 'Returned'),
(5, 1, 9, to_timestamp('2025-04-25', 'YYYY-MM-DD'), to_timestamp('2025-05-09', 'YYYY-MM-DD'), NULL, 'Issued'),
(6, 4, 10, to_timestamp('2025-07-15', 'YYYY-MM-DD'), to_timestamp('2025-07-19', 'YYYY-MM-DD'), to_timestamp('2025-07-18', 'YYYY-MM-DD'), 'Returned')
;



Insert into Reservation (ReservationID, MemberID, BookID, StaffID, ReservationDate, ExpiryDate, Status) values
(1, 1, 1, 1, to_timestamp('2025-05-01', 'YYYY-MM-DD'), to_timestamp('2025-05-10', 'YYYY-MM-DD'), 'Active'),
(2, 2, 8, 1, to_timestamp('2025-04-15', 'YYYY-MM-DD'), to_timestamp('2025-04-25', 'YYYY-MM-DD'), 'Cancelled'),
(3, 3, 6, 2, to_timestamp('2025-03-10', 'YYYY-MM-DD'), to_timestamp('2025-03-20', 'YYYY-MM-DD'), 'Expired'),
(4, 1, 3, 3, to_timestamp('2025-05-05', 'YYYY-MM-DD'), to_timestamp('2025-05-15', 'YYYY-MM-DD'), 'Active'),
(5, 4, 10, 3, to_timestamp('2025-04-20', 'YYYY-MM-DD'), to_timestamp('2025-04-30', 'YYYY-MM-DD'), 'Cancelled')
;



----------
CREATE OR REPLACE PROCEDURE find_transaction_details(book_title Book.Title%Type)
LANGUAGE 'plpgsql'
AS 
$BODY$
DECLARE
  b_title Book.Title%TYPE;
  m_name Member.Name%TYPE;
  t_status Transaction.Status%TYPE;
  t_date_issued Transaction.DateIssued%TYPE;
BEGIN
  SELECT b.Title, m.Name, tr.Status, tr.DateIssued
  INTO b_title, m_name, t_status, t_date_issued
  FROM Transaction tr
  Inner JOIN Book b ON tr.BookID = b.BookID
  Left JOIN Member m ON tr.MemberID = m.MemberID
  WHERE b.Title = book_title;
  RAISE NOTICE 'Book: %, Member: %, Status: %, Date Issued: %', b_title, m_name, t_status, t_date_issued;
END;
$BODY$

Call find_transaction_details('The Art of War');


----------

CREATE OR REPLACE VIEW CombinedMemberStaff AS
select MemberID as id, Name as info,'Member'as role
from Member

UNION ALL

select StaffID as id, SName as info, position as role
from Staff;

select * from CombinedMemberStaff;


----------
CREATE TABLE OnlineTransaction (
    PaymentMethod VARCHAR(100) NOT NULL
	constraint PaymentMethod check (PaymentMethod in ('CreditCard', 'MasterCard','MobilePayment','QRPayment'))
) INHERITS (Transaction);

CREATE TABLE OfflineTransaction (
    StoreLocation VARCHAR(100) NOT NULL,
	PaymentMethod VARCHAR(100) NOT NULL
	constraint StoreLocation check (StoreLocation in ('Springfield', 'New Mexico'))
	constraint PaymentMethod check (PaymentMethod in ('CreditCard', 'MasterCard','Cash','QRPayment'))
) INHERITS (Transaction);

Insert into OnlineTransaction (TransactionID, MemberID, BookID, DateIssued, DueDate, Status, PaymentMethod)
VALUES 
(1, 2, 1, to_timestamp('2025-05-01', 'YYYY-MM-DD'), to_timestamp('2025-05-15', 'YYYY-MM-DD'), 'Issued', 'CreditCard'),
(3, 4, 5, to_timestamp('2025-05-05', 'YYYY-MM-DD'), to_timestamp('2025-05-19', 'YYYY-MM-DD'), 'Issued', 'QRPayment'),
(5, 1, 9, to_timestamp('2025-04-25', 'YYYY-MM-DD'), to_timestamp('2025-05-09', 'YYYY-MM-DD'), 'Issued','MasterCard')
;


Insert into OfflineTransaction (TransactionID, MemberID, BookID, DateIssued, DueDate, 
ReturnDate , Status, PaymentMethod, StoreLocation)
VALUES 
(2, 5, 3, to_timestamp('2025-04-20', 'YYYY-MM-DD'), to_timestamp('2025-05-04', 'YYYY-MM-DD'), to_timestamp('2025-05-03', 'YYYY-MM-DD'), 
'Returned','CreditCard', 'New Mexico'),
(4, 1, 2, to_timestamp('2025-03-15', 'YYYY-MM-DD'), to_timestamp('2025-03-29', 'YYYY-MM-DD'), to_timestamp('2025-03-28', 'YYYY-MM-DD'), 
'Returned', 'Cash', 'Springfield'),
(6, 4, 10, to_timestamp('2025-07-15', 'YYYY-MM-DD'), to_timestamp('2025-07-19', 'YYYY-MM-DD'), to_timestamp('2025-07-18', 'YYYY-MM-DD'), 
'Returned','CreditCard', 'New Mexico')
;

CREATE OR REPLACE FUNCTION get_transaction_details()
RETURNS TABLE(TransactionID INT, BookID INT, DateIssued TIMESTAMP, Status VARCHAR)
LANGUAGE 'plpgsql' AS
$BODY$
BEGIN
    RETURN QUERY
    SELECT t.TransactionID, t.BookID, t.DateIssued, t.Status
    FROM Transaction t
    LEFT JOIN OnlineTransaction ot ON t.TransactionID = ot.TransactionID
    LEFT JOIN OfflineTransaction oft ON t.TransactionID = oft.TransactionID
    WHERE t.Status = 'Issued';
END;
$BODY$;
SELECT * FROM get_transaction_details();

----------
select
    EXTRACT(YEAR FROM DateIssued) AS transaction_year,
    EXTRACT(MONTH FROM DateIssued) AS transaction_month,
    COUNT(TransactionID) AS transaction_count
from
    Transaction
where
    DateIssued >= TIMESTAMP '2025-04-01 00:00:00'
    And DateIssued < TIMESTAMP '2025-05-01 00:00:00'
group by
    EXTRACT(YEAR FROM DateIssued),
    EXTRACT(MONTH FROM DateIssued)
order by
    transaction_year, transaction_month;


----------
select Status, MemberID, Count(TransactionID) AS transaction_count
from OfflineTransaction
GROUP BY ROLLUP(Status, MemberID);


