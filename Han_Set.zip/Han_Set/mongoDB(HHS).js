//Members
db.createCollection("members", {
  validator: {
  $jsonSchema: {
    bsonType: 'object',
    required: [
      'Name',
      'Address',
      'PhoneNumber',
      'Email',
      'StartDate'
    ],
    properties: {
      MemberID: {
        bsonType: 'int'
      },
      Name: {
        bsonType: 'string'
      },
      Address: {
        bsonType: 'object',
        properties: {
          street: {
            bsonType: 'string'
          },
          city: {
            bsonType: 'string'
          },
          postal_code: {
            bsonType: 'string'
          }
        },
        required: [
          'street',
          'city',
          'postal_code'
        ]
      },
      PhoneNumber: {
        bsonType: 'string'
      },
      Email: {
        bsonType: 'string'
      },
      StartDate: {
        bsonType: 'date'
      }
    }
  }
}
});

db.members.insertMany([
  {MemberID: 1, Name: "Jane Doe", Address: { street: "123 Elm St", city: "Springfield", postal_code: "62704" }, PhoneNumber: "555-1234", Email: "janedoe32@email.com", StartDate: new Date("2023-01-15T00:00:00Z") },
  {MemberID: 2, Name: "Smithy", Address: { street: "456 Oak Ave", city: "Metropolis", postal_code: "20001" }, PhoneNumber: "555-5678", Email:  "smith678@email.com", StartDate: new Date("2023-03-22T00:00:00Z") },
  {MemberID: 3, Name: "Elis Davis", Address: { street: "789 Pine Rd", city: "Gotham", postal_code: "07030" }, PhoneNumber: "555-8765", Email: "elisdavis795@email.com", StartDate: new Date("2023-05-10T00:00:00Z") },
  {MemberID: 4, Name: "Walter White", Address: { street: "308 Negra Arroyo", city: "New Mexico", postal_code: "09070" }, PhoneNumber: "545-9674", Email: "waltwhite357@gmail.com", StartDate: new Date("2023-04-01T00:00:00Z") },
  {MemberID: 5, Name: "Muhammad Matthew", Address: { street: "214 Daniela Plaza", city: "New Mexico", postal_code: "09056" }, PhoneNumber: "545-7439", Email: "Matthew37@gmail.com", StartDate: new Date("2023-04-28T00:00:00Z") }
]);


//Staff
db.createCollection("staff", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["SName", "position"],
      properties: {
        StaffID: {
          bsonType: "int"
        },
        SName: {
          bsonType: "string",  
        },
        position: {
          bsonType: "string",  
        }
      }
    }
  }
});

db.staff.insertMany([
  {StaffID: 1, SName: "Johnathan", position: "Receptionist"},
  {StaffID: 2, SName: "Eimi", position: "Receptionist"},
  {StaffID: 3, SName: "Anna", position: "Receptionist"}
]);




//Book
db.createCollection("books", {
   validator: {
      $jsonSchema: {
         bsonType: "object",
         required: ["Title", "Author", "PublishedYear", "Category", "AvailableCopies"],
         properties: {
            BookID: {
               bsonType: "int"
            },
            Title: {
               bsonType: "string"
            },
            Author: {
               bsonType: "string"
            },
            PublishedYear: {
               bsonType: "int"
            },
            Category: {
               enum: ["Art", "Biography", "Business", "Chick-lit", "Children's",
                 "Christian", "Classics", "Comics", "Contemporary", "Cookbooks",
                  "Crime", "Fantasy", "Fiction", "Historical fiction", "Horror",
                   "Humour and satire", "Non-Fiction", "Science", "History", "Technology"] 
            },
            AvailableCopies: {
               bsonType: "int"
            }
         }
      }
   }
});

db.books.insertMany([
  { BookID: 1, Title: "The Art of War", Author: "Sun Tzu", PublishedYear: 2005, Category: "History", AvailableCopies: 5 },
  { BookID: 2, Title: "Steve Jobs", Author: "Walter Isaacson", PublishedYear: 2011, Category: "Biography", AvailableCopies: 3 },
  { BookID: 3, Title: "Business Adventures", Author: "John Brooks", PublishedYear: 1969, Category: "Business", AvailableCopies: 4 },
  { BookID: 4, Title: "The Hunger Games", Author: "Suzanne Collins", PublishedYear: 2008, Category: "Fiction", AvailableCopies: 6 },
  { BookID: 5, Title: "The Hobbit", Author: "J.R.R. Tolkien", PublishedYear: 1937, Category: "Fantasy", AvailableCopies: 7 },
  { BookID: 6, Title: "Cooking Basics", Author: "Julia Child", PublishedYear: 1961, Category: "Cookbooks", AvailableCopies: 2 },
  { BookID: 7, Title: "The Complete Sherlock Holmes", Author: "Arthur Conan Doyle", PublishedYear: 1927, Category: "Classics", AvailableCopies: 8 },
  { BookID: 8, Title: "A Brief History of Time", Author: "Stephen Hawking", PublishedYear: 1988, Category: "Science", AvailableCopies: 5 },
  { BookID: 9, Title: "Clean Code", Author: "Robert C. Martin", PublishedYear: 2008, Category: "Technology", AvailableCopies: 10 },
  { BookID: 10, Title: "The Girl with the Dragon Tattoo", Author: "Stieg Larsson", PublishedYear: 2005, Category: "Crime", AvailableCopies: 4 }
]);



///Transaction
db.createCollection("Transaction", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["TransactionID", "MemberID", "BookID", "DateIssued", "DueDate", "Status"],
      properties: {

        TransactionID: { 
		bsonType: "int" 
		},

        MemberID: { 
		bsonType: "int" 
		},

        BookID: { 
		bsonType: "int"
		},

        DateIssued: {
		 bsonType: "date" 
		},


        DueDate: { 
		 bsonType: "date"
		},

        ReturnDate: { 
		 bsonType: ["date", "null"] 
		},

        Status: {
          enum: ["Issued", "Returned"]
		}
        }    
    }
  }
});


db.createCollection("OnlineTransaction", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["PaymentMethod"],
      properties: {
        TransactionID: { bsonType: "int" },
        PaymentMethod: { enum: ["CreditCard", "MasterCard", "MobilePayment", "QRPayment"] },
      }
    }
  }
});

db.createCollection("OfflineTransaction", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["PaymentMethod","StoreLocation"],
      properties: {
        TransactionID: { bsonType: "int" },
        PaymentMethod: { enum: ["CreditCard", "MasterCard", "Cash", "QRPayment"] },
	StoreLocation: { enum: ["Springfield", "New Mexico"] },
      }
    }
  }
});

db.Transaction.insertMany([
  {
    "TransactionID": 1,
    "MemberID": 2,
    "BookID": 1,
    "DateIssued": new Date("2025-05-01T00:00:00Z"),
    "DueDate": new Date("2025-05-15T00:00:00Z"),
    "ReturnDate": null,
    "Status": "Issued",
    "OnlineTransaction": [
      {
        "TransactionID": 1,
        "PaymentMethod": "CreditCard"
      }
    ]
  },
  {
    "TransactionID": 2,
    "MemberID": 5,
    "BookID": 3,
    "DateIssued": new Date("2025-04-20T00:00:00Z"),
    "DueDate": new Date("2025-05-04T00:00:00Z"),
    "ReturnDate": new Date("2025-05-03T00:00:00Z"),
    "Status": "Returned",
    "OfflineTransaction": [
      {
        "TransactionID": 2,
        "PaymentMethod": "CreditCard",
	"StoreLocation": "New Mexico"
      }
    ]
  },
  {
    "TransactionID": 3,
    "MemberID": 4,
    "BookID": 5,
    "DateIssued": new Date("2025-05-05T00:00:00Z"),
    "DueDate": new Date("2025-05-19T00:00:00Z"),
    "ReturnDate": null,
    "Status": "Issued",
    "OnlineTransaction": [
      {
        "TransactionID": 3,
        "PaymentMethod": "QRPayment"
      }
    ]
  },
  {
    "TransactionID": 4,
    "MemberID": 1,
    "BookID": 2,
    "DateIssued": new Date("2025-03-15T00:00:00Z"),
    "DueDate": new Date("2025-03-29T00:00:00Z"),
    "ReturnDate": new Date("2025-03-28T00:00:00Z"),
    "Status": "Returned",
    "OfflineTransaction": [
      {
        "TransactionID": 4,
        "PaymentMethod": "Cash",
        "StoreLocation": "Springfield"
      }
    ]
  },
  {
    "TransactionID": 5,
    "MemberID": 1,
    "BookID": 9,
    "DateIssued": new Date("2025-04-25T00:00:00Z"),
    "DueDate": new Date("2025-05-09T00:00:00Z"),
    "ReturnDate": null,
    "Status": "Issued",
    "OnlineTransaction": [
      {
        "TransactionID": 5,
        "PaymentMethod": "MasterCard"
      }
    ]
  },
  {
    "TransactionID": 6,
    "MemberID": 4,
    "BookID": 10,
    "DateIssued": new Date("2025-07-15T00:00:00Z"),
    "DueDate": new Date("2025-07-19T00:00:00Z"),
    "ReturnDate": new Date("2025-07-18T00:00:00Z"),
    "Status": "Returned",
    "OfflineTransaction": [
      {
        "TransactionID": 6,
        "PaymentMethod": "CreditCard",
        "StoreLocation": "New Mexico"
      }
    ]
  }
]);
db.OnlineTransaction.insertMany([
    {
        "TransactionID": 1, 
        "PaymentMethod": "CreditCard"
    },
    {
        "TransactionID": 3, 
        "PaymentMethod": "QRPayment"
    },
    {
        "TransactionID": 5,
        "PaymentMethod": "MasterCard"
    }
]);

db.OfflineTransaction.insertMany([
    {
        "TransactionID": 2, 
        "PaymentMethod": "CreditCard",
        "StoreLocation": "New Mexico"
    },
    {
        "TransactionID": 4,  
        "PaymentMethod": "Cash",
        "StoreLocation": "Springfield"
    },
    {
        "TransactionID": 6,  
        "PaymentMethod": "CreditCard",
        "StoreLocation": "New Mexico"
    }
]);


///Reservation
db.createCollection("Reservation", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["ReservationID", "MemberID", "BookID", "StaffID", "ReservationDate", "ExpiryDate", "Status"],
      properties: {
        ReservationID: {
          bsonType: "int"
        },
        MemberID: {
          bsonType: "int"
        },
        BookID: {
          bsonType: "int"
        },
        StaffID: {
          bsonType: "int"
        },
        ReservationDate: {
          bsonType: "date"
        },
        ExpiryDate: {
          bsonType: "date"
        },
        Status: {
          enum: ["Active", "Cancelled", "Expired"]
        }
      }
    }
  }
});

db.Reservation.insertMany([
  {
    "ReservationID": 1,
    "MemberID": 1,
    "BookID": 1,
    "StaffID": 1,
    "ReservationDate": new Date("2025-05-01T00:00:00Z"),
    "ExpiryDate": new Date("2025-05-10T00:00:00Z"),
    "Status": "Active"
  },
  {
    "ReservationID": 2,
    "MemberID": 2,
    "BookID": 8,
    "StaffID": 1,
    "ReservationDate": new Date("2025-04-15T00:00:00Z"),
    "ExpiryDate": new Date("2025-04-25T00:00:00Z"),
    "Status": "Cancelled"
  },
  {
    "ReservationID": 3,
    "MemberID": 3,
    "BookID": 6,
    "StaffID": 2,
    "ReservationDate": new Date("2025-03-10T00:00:00Z"),
    "ExpiryDate": new Date("2025-03-20T00:00:00Z"),
    "Status": "Expired"
  },
  {
    "ReservationID": 4,
    "MemberID": 1,
    "BookID": 3,
    "StaffID": 3,
    "ReservationDate": new Date("2025-05-05T00:00:00Z"),
    "ExpiryDate": new Date("2025-05-15T00:00:00Z"),
    "Status": "Active"
  },
  {
    "ReservationID": 5,
    "MemberID": 4,
    "BookID": 10,
    "StaffID": 3,
    "ReservationDate": new Date("2025-04-20T00:00:00Z"),
    "ExpiryDate": new Date("2025-04-30T00:00:00Z"),
    "Status": "Cancelled"
  }
]);


//query 1 join
db.Transaction.aggregate([
  {
    $lookup: {
      from: "books",
      localField: "BookID",
      foreignField: "BookID",
      as: "book_info"
    }
  },
  { $unwind: "$book_info" },
  {
    $lookup: {
      from: "members",
      localField: "MemberID",
      foreignField: "MemberID",
      as: "member_info"
    }
  },
  { $unwind: "$member_info" },
  {
    $match: {
      "book_info.Title": "The Art of War"
    }
  },
  {
    $project: {
      _id: 0,
      bookTitle: "$book_info.Title",
      memberName: "$member_info.Name",
      transactionStatus: "$Status",
      transactionDateIssued: "$DateIssued"
    }
  }
])



////2 union
db.members.aggregate([
  {$project: { _id: 0, id: "$MemberID", info: "$Name", role: { $literal: "Member" } 
    }},
  {
    $unionWith: {
      coll: "staff", 
      pipeline: [
        {$project:  {_id: 0, id: "$StaffID", info:"$SName", role: "$position" }}
      ]}}
]);


////3 query
db.Transaction.aggregate([
    { $match: { Status: 'Issued' } },
  {
    $lookup: {
      from: "OnlineTransaction",
      localField: "TransactionID",
      foreignField: "TransactionID",
      as: "online_info"
    }
  },
    {
    $lookup: {
      from: "OfflineTransaction",
      localField: "TransactionID",
      foreignField: "TransactionID",
      as: "offline_info"
    }},
 
    {$project: {_id: 0, TransactionID: 1, BookID: 1, DateIssued: 1, Status: 1}}
])


////4 query
db.Transaction.aggregate([
   {
    $match: {
      DateIssued: {
        $gte: ISODate("2024-01-01T00:00:00.000Z"),
        $lt: ISODate("2025-05-01T00:00:00.000Z")
      }
    }
  },
  {
    $project: {
      transaction_year: { $year: "$DateIssued" },
      transaction_month: { $month: "$DateIssued" }
    }
  },
  {
    $group: {
      _id: { year: "$transaction_year", month: "$transaction_month" },
      transaction_count: { $sum: 1 }
    }
  },
  {
    $project: {
      _id: 0,
      transaction_year: "$_id.year",
      transaction_month: "$_id.month",
      transaction_count: 1
    }
  },
  {
    $sort: { transaction_year: 1, transaction_month: 1 }
  }
])


///5 query
db.OfflineTransaction.aggregate([
 
  {$group: {_id: { status: "$Status", memberID: "$MemberID" }, transaction_count: { $sum: 1 }}

},
 
  { $sort: { "transaction_count:": 1} }
])


